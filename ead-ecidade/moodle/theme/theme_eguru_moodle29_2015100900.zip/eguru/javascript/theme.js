$(function(){
    $( "table" ).wrap(function(){
    var ctab_obj = $(this);
    if (ctab_obj.parent('div').hasClass('no-overflow')) {
    // Todo
    } else {
    return "<div class='no-overflow'></div>";
    }

    });
 });