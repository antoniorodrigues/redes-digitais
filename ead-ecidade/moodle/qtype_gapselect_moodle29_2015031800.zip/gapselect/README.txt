Gap-select question type

This question type allows students to complete a paragraph of text by selecting the
missing words using drop-down menus. You can make questions like this using the
Cloze question type, but this question type is easier for teachers to get up, and
presents the feedback in a more accessible way.

The question type was created by Jamie Pratt (http://jamiep.org/) paid for by
the Open University (http://www.open.ac.uk/).


This version of this question type is compatible with Moodle 2.5+. There are
other versions available for Moodle 2.3+.

To install using git, type this command in the root of your Moodle install
    git clone git@github.com:moodleou/moodle-qtype_gapselect.git question/type/gapselect
Then add question/type/gapselect to your git ignore.

Alternatively, download the zip from
    https://github.com/moodleou/moodle-qtype_gapselect/zipball/master
unzip it into the question/type folder, and then rename the new folder to gapselect.
